#ifndef FUNCIONES_H
#define FUNCIONES_H

int esPrimo(int numero);
unsigned long long factorial(int numero);
void contarDigitos(int numero, int *pares, int *impares);
void mostrarMultiplosDe3(int numero);

#endif
